# Context index

- `previous-artifacts/life-management/`: earlier local Codex起步包，含完整方法、模板、研究、验证记录和脚本。
- `previous-artifacts/人生管理系统-投资人路演.pptx`: 24页融资讨论稿。
- `context/人生管理系统4.0-完整设计.md`: 系统4.0完整设计。
- `context/科学决策引擎3.0详细流程图.svg`: 八阶段流程图。
- `context/科学决策引擎3.0子智能体协作图.svg`: 协作图。

历史材料中的结论仍需按其记录日期和验证范围理解；它们不是已经上线的软件或市场验证。
